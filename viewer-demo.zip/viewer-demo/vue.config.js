module.exports = {
  lintOnSave: true
}
