<template>
  <div class="oauth">
    <div id="main">
        Authorize me!
    </div>
  </div>
</template>
